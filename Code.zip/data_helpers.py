import numpy as np
import re
import itertools
from collections import Counter
import json


def clean_str(string):
    """
    Tokenization/string cleaning for all datasets except for SST.
    Original taken from https://github.com/yoonkim/CNN_sentence/blob/master/process_data.py
    """
    string = re.sub(r"[^A-Za-z0-9(),!?\'\`]", " ", string)
    string = re.sub(r"\'s", " \'s", string)
    string = re.sub(r"\'ve", " \'ve", string)
    string = re.sub(r"n\'t", " n\'t", string)
    string = re.sub(r"\'re", " \'re", string)
    string = re.sub(r"\'d", " \'d", string)
    string = re.sub(r"\'ll", " \'ll", string)
    string = re.sub(r",", " , ", string)
    string = re.sub(r"!", " ! ", string)
    string = re.sub(r"\(", " \( ", string)
    string = re.sub(r"\)", " \) ", string)
    string = re.sub(r"\?", " \? ", string)
    string = re.sub(r"\s{2,}", " ", string)
    return string.strip().lower()


def load_data_and_labels(data_file):
    """
    Loads data from files, splits the data into words and generates labels.
    Returns split sentences and labels.
    """
    data = json.load(open(data_file))

    x_text = []
    y = []

    for instance in data:

        if instance["sentiment"] == -1:
            y.append([0,0,1.0])
        elif instance["sentiment"] == 0:
            y.append([0,1.0,0])
        elif instance["sentiment"] == 1:
            y.append([1.0,0,0])
        else:
            continue
        x_text.append(clean_str(instance["text"]))

    return [x_text, np.array(y)]


def batch_iter(data, batch_size, num_epochs, shuffle=True):
    """
    Generates a batch iterator for a dataset.
    """
    data = np.array(data)
    data_size = len(data)
    num_batches_per_epoch = int((len(data)-1)/batch_size) + 1
    for epoch in range(num_epochs):
        # Shuffle the data at each epoch
        if shuffle:
            shuffle_indices = np.random.permutation(np.arange(data_size))
            shuffled_data = data[shuffle_indices]
        else:
            shuffled_data = data
        start_progress_log(epoch, num_batches_per_epoch)
        epcomplete = False
        for batch_num in range(num_batches_per_epoch):
            start_index = batch_num * batch_size
            end_index = min((batch_num + 1) * batch_size, data_size)
            update_progress_log(epoch, batch_num, num_batches_per_epoch)
            if batch_num == (num_batches_per_epoch - 1):
                epcomplete = True
            yield shuffled_data[start_index:end_index], epcomplete

def start_progress_log(epoch, num_batches_per_epoch):
    printProgressBar(0,num_batches_per_epoch,prefix='Epoch {}: [{}/{}]'.format(epoch, 0,num_batches_per_epoch), suffix='Complete', length=50)

def update_progress_log(batch_num, epoch, num_batches_per_epoch):
    printProgressBar(0,num_batches_per_epoch,prefix='Epoch {}: [{}/{}]'.format(epoch, batch_num + 1,num_batches_per_epoch), suffix='Complete', length=50)

def printProgressBar (iteration, total, prefix = '', suffix = '', decimals = 1, length = 100, fill = '█'):
    """
    Call in a loop to create terminal progress bar
    @params:
        iteration   - Required  : current iteration (Int)
        total       - Required  : total iterations (Int)
        prefix      - Optional  : prefix string (Str)
        suffix      - Optional  : suffix string (Str)
        decimals    - Optional  : positive number of decimals in percent complete (Int)
        length      - Optional  : character length of bar (Int)
        fill        - Optional  : bar fill character (Str)
    """
    percent = ("{0:." + str(decimals) + "f}").format(100 * (iteration / float(total)))
    filledLength = int(length * iteration // total)
    bar = fill * filledLength + '-' * (length - filledLength)
    print('\r%s |%s| %s%% %s' % (prefix, bar, percent, suffix), end = '\r')
    # Print New Line on Complete
    if iteration == total:
        print()
