import collections
import math
import os
import sys
import argparse
import random
import re
from tempfile import gettempdir
import zipfile

import numpy as np
import tensorflow as tf

from keras import backend as K
from keras.layers import Embedding
from keras.layers import Dense, Input, Flatten
from keras.layers import Conv1D, MaxPooling1D, Embedding, Merge, Dropout, LSTM, GRU, Bidirectional, TimeDistributed
from keras.models import Model
from keras.engine.topology import Layer, InputSpec
from keras.preprocessing.text import Tokenizer

from ortho import ortho_syllable

TRAIN_DATA_FILE = "../Data/code_mixed_50k.txt"
BATCH_SIZE = 128


def clean_str(string):
    """
    Tokenization/string cleaning for all datasets except for SST.
    Original taken from https://github.com/yoonkim/CNN_sentence/blob/master/process_data.py
    """
    string = re.sub(r"[^A-Za-z0-9(),!?\'\`]", " ", string)
    string = re.sub(r"\'s", " \'s", string)
    string = re.sub(r"\'ve", " \'ve", string)
    string = re.sub(r"n\'t", " n\'t", string)
    string = re.sub(r"\'re", " \'re", string)
    string = re.sub(r"\'d", " \'d", string)
    string = re.sub(r"\'ll", " \'ll", string)
    string = re.sub(r",", " , ", string)
    string = re.sub(r"!", " ! ", string)
    string = re.sub(r"\(", " \( ", string)
    string = re.sub(r"\)", " \) ", string)
    string = re.sub(r"\?", " \? ", string)
    string = re.sub(r"\s{2,}", " ", string)

    return string.strip().lower()


def break_in_subword(f, add_word = False):

    texts = []
    word_texts = []

    data = open(f,"r").read().splitlines()
    for x in data[:-1]:
        text = x
        text = ' '.join(re.sub("(@[A-Za-z0-9]+)|([^0-9A-Za-z \t])|(\w+:\/\/\S+)"," ",text).split())
        cleaned_text = clean_str(text)
        splitted_text = cleaned_text.split()
        joined_text = []
        word_list = []
        for y in splitted_text:
            if(not y.isspace()):
                joined_text.append(ortho_syllable(y.strip()))
                if add_word:
                    word_list.append(y.strip())
        texts.append(joined_text)
        if add_word:
            word_texts.append(word_list)

    if add_word:
        return texts, word_texts
    else:
        return texts


def maptosubword(files):

    texts = []

    for f in files:
        f_text = break_in_subword(f)
        for x in f_text:
            temp = []
            for y in x:
                temp.extend(y)
            texts.append(str(' '.join(temp)))

    tokenizer = Tokenizer(filters='!"#$%&()*+,-./:;=?@[\\]^_`{|}~\t\n')
    tokenizer.fit_on_texts(texts)

    tokenizer.word_index['<<SPAD>>'] = len(tokenizer.word_index) + 1

    return tokenizer


def maptoword(files):

    texts = []
    f_text = []

    for f in files:
        _, f_text = break_in_subword(f, add_word=True)
        for x in f_text:
            texts.append(' '.join(x))

    tokenizer = Tokenizer()
    tokenizer.fit_on_texts(texts)

    tokenizer.word_index['<<WPAD>>'] = len(tokenizer.word_index) + 1

    return tokenizer


def get_sequences(texts, max_slen, max_wlen, tokenizer):

    max_sent_len = 0
    max_word_len = 0
    avg_sent_len = 0
    avg_word_len = 0
    n_words = 0
    n_owords = 0
    n_osents = 0

    data = np.full(
        (len(texts), max_slen, max_wlen),
        tokenizer.word_index['<<SPAD>>'], dtype='int64')

    for i in range(len(texts)):
        max_sent_len = max(max_sent_len, len(texts[i]))
        avg_sent_len += len(texts[i])
        if len(texts[i]) > max_slen:
            n_osents += 1
        for j in range(len(texts[i])):
            if j<max_slen:
                max_word_len = max(max_word_len, len(texts[i][j]))
                avg_word_len += len(texts[i][j])
                n_words += 1
                if len(texts[i][j])> max_wlen:
                    n_owords += 1
                for k in range(len(texts[i][j])):
                    if k<5:
                        if texts[i][j][k] in tokenizer.word_index:
                            data[i][j][k] = tokenizer.word_index[texts[i][j][k]]
                        else:
                            data[i][j][k] = 0
                    else:
                        break
            else:
                break

    print("Max sent len {}, Max word len {}".format(max_sent_len, max_word_len))
    print("Avg sent len {}, Avg word len {}".format(avg_sent_len/len(texts), avg_word_len/n_words))
    print("Out sent {}, Out words {}".format(n_osents, n_owords))

    return data

def get_wordsequences(wtext, wtokenizer, max_slen):

    data = np.full(
        (len(wtext), max_slen),
        wtokenizer.word_index['<<WPAD>>'], dtype='int64')

    for i in range(len(wtext)):
        for j in range(len(wtext[i])):
            if j < max_slen:
                if wtext[i][j] in wtokenizer.word_index:
                    data[i][j] = wtokenizer.word_index[wtext[i][j]]
                else:
                    data[i][j] = 0
            else:
                break

    return data

stext, wtext = break_in_subword(TRAIN_DATA_FILE, add_word = True)
stokenizer = maptosubword([TRAIN_DATA_FILE,])
inv_subword_map = {stokenizer.word_index[k] : k for k in stokenizer.word_index}
sub_word_sequences = get_sequences(stext, 50, 5, stokenizer)
wtokenizer = maptoword([TRAIN_DATA_FILE])
inv_word_map = {wtokenizer.word_index[k] : k for k in wtokenizer.word_index}
word_sequences = get_wordsequences(wtext, wtokenizer, 50)
indices = np.arange(1, len(wtokenizer.word_index)+1)

word_to_subword_index_map = {}

# Step 3: Function to generate a training batch for the skip-gram model.
def generate_batch(curr_index, indices, skip_window=2, n_negsample=10, batch_size=BATCH_SIZE):
    wbatch = []
    sbatch = []
    labels = []
    slabels = []

    count = 0

    neg_samples = []
    neg_ssamples = []
    span = 2 * skip_window + 1  # [ skip_window target skip_window ]

    temp_index = [0,0]
    epoch_end = False

    for i in range(curr_index[0], sub_word_sequences.shape[0]):
        s_end = False
        for j in range(curr_index[1], 50):
            if word_sequences[i][j] == wtokenizer.word_index["<<WPAD>>"]:
                break
            elif j<skip_window or j>=(50-skip_window):
                labels.append(wtokenizer.word_index["<<WPAD>>"])
                sword_array = np.full((5,), stokenizer.word_index["<<SPAD>>"])
                slabels.append(sword_array)
                wbatch.append(word_sequences[i][j])
                sbatch.append(np.array(sub_word_sequences[i][j]))

                count += 1

                knegsamples = np.random.choice(indices, n_negsample)
                neg_samples.append(knegsamples)
                temp_subsamples = []

                for k in knegsamples:
                    rword = inv_word_map[k]
                    sword_array = np.full((5,), stokenizer.word_index["<<SPAD>>"])
                    sword_list = ortho_syllable(rword)
                    for l in range(min(5,len(sword_list))):
                        sword_array[l] = stokenizer.word_index[sword_list[l]]
                    temp_subsamples.append(sword_array[l])

                neg_ssamples.append(np.array(temp_subsamples))
            else:
                for k in range(j-skip_window, j+skip_window):
                    if k!=j:
                        labels.append(word_sequences[i][k])
                        slabels.append(sub_word_sequences[i][k])
                        wbatch.append(word_sequences[i][j])
                        sbatch.append(sub_word_sequences[i][j])

                        count += 1

                        knegsamples = np.random.choice(indices, n_negsample)
                        neg_samples.append(knegsamples)
                        temp_subsamples = []

                        for k in knegsamples:
                            rword = inv_word_map[k]
                            sword_array = np.full((5,), stokenizer.word_index["<<SPAD>>"])
                            sword_list = ortho_syllable(rword)
                            for l in range(min(5,len(sword_list))):
                                sword_array[l] = stokenizer.word_index[sword_list[l]]
                            temp_subsamples.append(sword_array[l])

                        neg_ssamples.append(np.array(temp_subsamples))

            if(count==batch_size):
                temp_index[0] = curr_index[0]
                temp_index[1] = curr_index[1]

                if curr_index[1] == 49:
                    temp_index[0] = temp_index[0] + 1
                    temp_index[1] = 0
                else:
                    temp_index[1] += 1

                break

            if(j==49 and i==(sub_word_sequences.shape[0]-1)):
                epoch_end = True
                i = -1
                j = -1


    wbatch = np.array(wbatch)
    sbatch = np.array(sbatch)
    labels = np.reshape(np.array(labels),(-1,1))
    slabels = np.array(slabels)
    neg_wsamples = np.array(neg_samples)
    neg_ssamples = np.array(neg_ssamples)

    return wbatch, sbatch, neg_wsamples, neg_ssamples, labels, slables, temp_index, epoch_end


# Step 4: Build and train a skip-gram model.
embedding_size = 100  # Dimension of the embedding vector.

valid_size = 16  # Random set of words to evaluate similarity on.
valid_window = 100  # Only pick dev samples in the head of the distribution.
valid_examples = np.random.choice(valid_window, valid_size, replace=False)

embedding_matrix = np.random.uniform(
    low=0.1, high=0.5,
    size=(len(stokenizer.word_index)+1, embedding_size))

graph = tf.Graph()

with graph.as_default():

    # Input data.
    with tf.name_scope('inputs'):
        #wbatch = tf.placeholder(tf.int32, shape=[None])
        sbatch = tf.placeholder(tf.int32, shape=[BATCH_SIZE, 5])
        #labels = tf.placeholder(tf.int32, shape=[None, 1])
        slabels = tf.placeholder(tf.int32, shape=[BATCH_SIZE, 5])
        #neg_wsamples = tf.placeholder(tf.int32, shape=[None, 10])
        neg_ssamples = tf.placeholder(tf.int32, shape=[BATCH_SIZE, 10, 5])
        #valid_dataset = tf.constant(valid_examples, dtype=tf.int32)
        alpha1 = tf.constant(0.01)

    # Ops and variables pinned to the CPU because of missing GPU implementation
    with tf.device('/cpu:0'):

        embedding_layer = Embedding(len(stokenizer.word_index)+1,
                                    embedding_size,
                                    weights=[embedding_matrix],
                                    input_length=5,
                                    trainable=True)

    word_input = Input(shape=(5,), dtype='int32')
    embedded_sequences = embedding_layer(word_input)
    l_lstm = Bidirectional(LSTM(100))(embedded_sequences)
    word_encoder = Model(word_input, l_lstm)

    s_encoded = word_encoder(sbatch)
    l_encoded = word_encoder(slabels)

    sl_multiplied = tf.multiply(s_encoded, l_encoded)
    sl_dotproduct = tf.reduce_sum(sl_multiplied, 1)
    sl_result_p = tf.reduce_sum(tf.log(tf.sigmoid(sl_dotproduct)))

    neg_input = Input(shape=(10, 5), dtype='int32')
    neg_encoder = TimeDistributed(word_encoder)(neg_input)
    n_model = Model(neg_input, neg_encoder)

    n_encoded = n_model(neg_ssamples)
    sn_mult_broadcast = tf.multiply(tf.expand_dims(s_encoded, 1), n_encoded)
    sn_dot_product = tf.reduce_sum(sn_mult_broadcast, 2)
    sn_result_n = tf.reduce_sum(tf.log(tf.sigmoid(sn_dot_product)))

    reg_losses = tf.get_collection(tf.GraphKeys.REGULARIZATION_LOSSES)
    reg_constant = 0.01
    loss = sl_result_p - alpha1*sn_result_n + reg_constant*sum(reg_losses)

    # Construct the SGD optimizer using a learning rate of 1.0.
    with tf.name_scope('optimizer'):
        optimizer = tf.train.RMSPropOptimizer(0.01).minimize(loss)

    # Add variable initializer.
    init = tf.global_variables_initializer()


# Step 5: Begin training.
num_epochs = 100

with tf.Session(graph=graph) as session:
    K.set_session(session)

    # We must initialize all variables before we use them.
    init.run()
    print('Initialized')

    average_loss = 0

    for epoch in range(num_epochs):
        curr_index = [0,0]
        while curr_index[0] < sub_word_sequences.shape[0]:
            batch_data = generate_batch(curr_index, indices)
            curr_index = batch_data[6]
            feed_dict = {
                sbatch:batch_data[1],
                slabels:batch_data[5],
                neg_ssamples:batch_data[3]}
            _, loss = session.run([optimizer, loss], feed_dict=feed_dict)

            average_loss += loss

            if batch_data[7]:
                break

        average_loss = average_loss/sub_word_sequences.shape[0]

        print("Average Loss {}".format(average_loss))
