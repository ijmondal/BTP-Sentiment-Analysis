import numpy as np
import tensorflow as tf
import math

class CNNModel():
    """
    CNN model for detection of sentiment
    """

    def __init__(self, sentence_length=80, n_classes=2, conv_filter_sizes=None, pool_filter_sizes=None, n_filters=None, w2vec=None, l2_reg_lambda=0.0):
        """
        sentence_length : length of normalized sentences after padding
        n_classes : number of classes
        conv_filter_sizes : [n_layers * number_of_filter]
        pool_filter_sizes : [n_layers * number_of_filter]
        n_filters : [n_layers * number_of_filter_of_each_type_at_some_layer]
        w2vec : word2vec model
        """

        self.sentence_length = sentence_length

        dim_X = [None, sentence_length]
        self.X = tf.placeholder(tf.int32, dim_X, name="input_data")

        dim_y = [None, n_classes]
        self.y = tf.placeholder(tf.float32, dim_y, name="input_label")

        self.dropout_keep_prob = tf.placeholder(
            tf.float32, name="dropout_keep_prob")

        # Keeping track of l2 regularization loss
        l2_loss = tf.constant(0.0)

        with tf.device('/cpu:0'), tf.name_scope("embedding_layer"):
            self.construct_embedding_layer(w2vec)

        self.input_tensor = self.dense_embedding
        in_channel = 1
        curr_height = [self.sentence_length]*len(conv_filter_sizes[0])

        # first conv pool layer
        with tf.name_scope("conv_pool_layer_{}".format(0)):
            pooled_outputs, in_channel, curr_height = self.construct_conv_pool_layer(
                self.input_tensor,
                conv_filter_sizes[0],
                n_filters[0],
                in_channel,
                curr_height)

        # upper conv pool layer
        for i in range(1,len(conv_filter_sizes)):
            pooled_outputs, in_channel, curr_height = self.upper_conv_pool_layer(
                pooled_outputs,
                conv_filter_sizes[i],
                n_filters[i],
                in_channel,
                curr_height)

        # combine different feature maps

        combined_tensor = tf.concat(pooled_outputs, 1)

        # Fold the embed_size to half
        with tf.name_scope("folding"):
            folded_tensor = tf.nn.avg_pool(
                combined_tensor,
                ksize=[1, 1, 2, 1],
                strides=[1, 1, 2, 1],
                padding='SAME',
                name="pool")

        # Add dropout layer
        with tf.name_scope("dropout_layer"):
            self.dropout_layer = tf.nn.dropout(folded_tensor, 0.5)

        # Reshape tensor
        reshaped_tensor = tf.reshape(
            self.dropout_layer,
            [-1, in_channel * ((self.embed_size+1)//2) * sum(curr_height)])

        # Final scores and predictions
        with tf.name_scope("fully_connected_layer"):
            W = tf.Variable(tf.truncated_normal(
                [in_channel * ((self.embed_size+1)//2) * sum(curr_height), n_classes],
                stddev=0.1),
                name="W")
            b = tf.Variable(tf.constant(0.1, shape=[n_classes]), name="b")
            l2_loss += tf.nn.l2_loss(W)
            l2_loss += tf.nn.l2_loss(b)
            self.scores = tf.nn.xw_plus_b(reshaped_tensor, W, b, name="scores")
            self.predictions = tf.argmax(self.scores, 1, name="predictions")

        # CalculateMean cross-entropy loss
        with tf.name_scope("loss"):
            losses = tf.nn.softmax_cross_entropy_with_logits(
                logits=self.scores,
                labels=self.y)
            self.loss = tf.reduce_mean(losses) + l2_reg_lambda * l2_loss

        # Accuracy
        with tf.name_scope("accuracy"):
            correct_predictions = tf.equal(self.predictions, tf.argmax(self.y, 1))
            self.accuracy = tf.reduce_mean(tf.cast(correct_predictions, "float"), name="accuracy")

    def construct_embedding_layer(self, w2vec):
        """
        Constructs the embedding_layer
        """

        self.vocab_size = w2vec.vsz
        self.embed_size = w2vec.dsz

        # The embedding lookup matrix
        W = tf.Variable(
            tf.constant(w2vec.weights, dtype=tf.float32),
            name="W", trainable=True)

        e0 = tf.scatter_update(
            W, tf.constant(0, dtype=tf.int32, shape=[1]),
            tf.zeros(shape=[1, self.embed_size]))

        with tf.control_dependencies([e0]):
            self.dense_embedding = tf.nn.embedding_lookup(W, self.X)
            # shape(dense_embedding) is [n_sentences*sentence_length*embed_size]
            # appending one more dimension as channel
            # self.one_channel_embedding = tf.expand_dims(dense_embedding, -1)

    def construct_conv_pool_layer(self, input_tensor, conv_filter, num_filters, in_channel, curr_height):
        """
        Constructs the convolution + maxpooling layer
        """

        # Increase dimension of padded_tensor
        expanded_tensor = tf.expand_dims(input_tensor, -1)

        pooled_outputs = []
        for i in range(len(conv_filter)):
            with tf.name_scope("conv-maxpool-{}".format(i)):

                filter_shape = [
                    conv_filter[i],
                    1,
                    in_channel,
                    num_filters]

                W = tf.Variable(
                    tf.truncated_normal(filter_shape, stddev=0.1), name="W")

                b = tf.Variable(tf.constant(0.1, shape=[num_filters]), name="b")

                conv = tf.nn.conv2d(
                    expanded_tensor,
                    W,
                    strides=[1,1,1,1],
                    padding="VALID",
                    name="conv")
                # RELU Non-linearity
                h = tf.nn.relu(tf.nn.bias_add(conv, b), name="relu")

                pooled = tf.nn.max_pool(
                    h,
                    ksize=[1, 2, 1, 1],
                    strides=[1, 2, 1, 1],
                    padding='SAME',
                    name="pool")
                pooled_outputs.append(pooled)

        in_channel = num_filters
        curr_height = [(x-f+2)//2 for x,f in zip(curr_height, conv_filter)]

        return pooled_outputs, in_channel, curr_height


    def upper_conv_pool_layer(self, pooled_outputs, conv_filter, num_filters, in_channel, curr_height):
        """
        Constructs the convolution + maxpooling layer
        """

        # Increase dimension of padded_tensor
        # expanded_tensors = [tf.expand_dims(input_tensor, -1) for input_tensor in pooled_outputs]

        curr_pooled_outputs = []

        for i in range(len(pooled_outputs)):
            with tf.name_scope("conv-maxpool-{}".format(i)):

                filter_shape = [
                    conv_filter,
                    1,
                    in_channel,
                    num_filters]

                W = tf.Variable(
                    tf.truncated_normal(filter_shape, stddev=0.1), name="W")

                b = tf.Variable(tf.constant(0.1, shape=[num_filters]), name="b")

                conv = tf.nn.conv2d(
                    pooled_outputs[i],
                    W,
                    strides=[1,1,1,1],
                    padding="VALID",
                    name="conv")
                # RELU Non-linearity
                h = tf.nn.relu(tf.nn.bias_add(conv, b), name="relu")

                pooled = tf.nn.max_pool(
                    h,
                    ksize=[1, 2, 1, 1],
                    strides=[1, 2, 1, 1],
                    padding='SAME',
                    name="pool")
                curr_pooled_outputs.append(pooled)

        in_channel = num_filters
        curr_height = [(x-conv_filter+2)//2 for x in curr_height]

        return curr_pooled_outputs, in_channel, curr_height


class DynamicLSTMModel():
    """
    LSTM model for detection of sentiment
    """

    def __init__(self, sentence_length=80, n_classes=2, conv_filter_sizes=None, pool_filter_sizes=None, n_filters=None, w2vec=None, l2_reg_lambda=0.0):
        """
        sentence_length : length of normalized sentences after padding
        n_classes : number of classes
        conv_filter_sizes : [n_layers * number_of_filter]
        pool_filter_sizes : [n_layers * number_of_filter]
        n_filters : [n_layers * number_of_filter_of_each_type_at_some_layer]
        w2vec : word2vec model
        """

        self.sentence_length = sentence_length

        dim_X = [None, sentence_length]
        self.X = tf.placeholder(tf.int32, dim_X, name="input_data")

        dim_y = [None, n_classes]
        self.y = tf.placeholder(tf.float32, dim_y, name="input_label")

        self.dropout_keep_prob = tf.placeholder(
            tf.float32, name="dropout_keep_prob")

        # Keeping track of l2 regularization loss
        l2_loss = tf.constant(0.0)

        with tf.device('/cpu:0'), tf.name_scope("embedding_layer"):
            self.construct_embedding_layer(w2vec)

        self.input_tensor = self.dense_embedding
        in_channel = 1
        curr_height = [self.sentence_length]*len(conv_filter_sizes[0])

        # first conv pool layer
        with tf.name_scope("conv_pool_layer_{}".format(0)):
            pooled_outputs, in_channel, curr_height = self.construct_conv_pool_layer(
                self.input_tensor,
                conv_filter_sizes[0],
                n_filters[0],
                in_channel,
                curr_height)

        # upper conv pool layer
        for i in range(1,len(conv_filter_sizes)):
            pooled_outputs, in_channel, curr_height = self.upper_conv_pool_layer(
                pooled_outputs,
                conv_filter_sizes[i],
                n_filters[i],
                in_channel,
                curr_height)

        # combine different feature maps

        combined_tensor = tf.concat(pooled_outputs, 1)

        # Fold the embed_size to half
        with tf.name_scope("folding"):
            folded_tensor = tf.nn.avg_pool(
                combined_tensor,
                ksize=[1, 1, 2, 1],
                strides=[1, 1, 2, 1],
                padding='SAME',
                name="pool")

        # Add dropout layer
        with tf.name_scope("dropout_layer"):
            self.dropout_layer = tf.nn.dropout(folded_tensor, 0.5)

        # Reshape tensor
        reshaped_tensor = tf.reshape(
            self.dropout_layer,
            [-1, in_channel * ((self.embed_size+1)//2) * sum(curr_height)])

        # Final scores and predictions
        with tf.name_scope("fully_connected_layer"):
            W = tf.Variable(tf.truncated_normal(
                [in_channel * ((self.embed_size+1)//2) * sum(curr_height), n_classes],
                stddev=0.1),
                name="W")
            b = tf.Variable(tf.constant(0.1, shape=[n_classes]), name="b")
            l2_loss += tf.nn.l2_loss(W)
            l2_loss += tf.nn.l2_loss(b)
            self.scores = tf.nn.xw_plus_b(reshaped_tensor, W, b, name="scores")
            self.predictions = tf.argmax(self.scores, 1, name="predictions")

        # CalculateMean cross-entropy loss
        with tf.name_scope("loss"):
            losses = tf.nn.softmax_cross_entropy_with_logits(
                logits=self.scores,
                labels=self.y)
            self.loss = tf.reduce_mean(losses) + l2_reg_lambda * l2_loss

        # Accuracy
        with tf.name_scope("accuracy"):
            correct_predictions = tf.equal(self.predictions, tf.argmax(self.y, 1))
            self.accuracy = tf.reduce_mean(tf.cast(correct_predictions, "float"), name="accuracy")

    def construct_embedding_layer(self, w2vec):
        """
        Constructs the embedding_layer
        """

        self.vocab_size = w2vec.vsz
        self.embed_size = w2vec.dsz

        # The embedding lookup matrix
        W = tf.Variable(
            tf.constant(w2vec.weights, dtype=tf.float32),
            name="W", trainable=True)

        e0 = tf.scatter_update(
            W, tf.constant(0, dtype=tf.int32, shape=[1]),
            tf.zeros(shape=[1, self.embed_size]))

        with tf.control_dependencies([e0]):
            self.dense_embedding = tf.nn.embedding_lookup(W, self.X)
            # shape(dense_embedding) is [n_sentences*sentence_length*embed_size]
            # appending one more dimension as channel
            # self.one_channel_embedding = tf.expand_dims(dense_embedding, -1)

    def construct_conv_pool_layer(self, input_tensor, conv_filter, num_filters, in_channel, curr_height):
        """
        Constructs the convolution + maxpooling layer
        """

        # Increase dimension of padded_tensor
        expanded_tensor = tf.expand_dims(input_tensor, -1)

        pooled_outputs = []
        for i in range(len(conv_filter)):
            with tf.name_scope("conv-maxpool-{}".format(i)):

                filter_shape = [
                    conv_filter[i],
                    1,
                    in_channel,
                    num_filters]

                W = tf.Variable(
                    tf.truncated_normal(filter_shape, stddev=0.1), name="W")

                b = tf.Variable(tf.constant(0.1, shape=[num_filters]), name="b")

                conv = tf.nn.conv2d(
                    expanded_tensor,
                    W,
                    strides=[1,1,1,1],
                    padding="VALID",
                    name="conv")
                # RELU Non-linearity
                h = tf.nn.relu(tf.nn.bias_add(conv, b), name="relu")

                pooled = tf.nn.max_pool(
                    h,
                    ksize=[1, 2, 1, 1],
                    strides=[1, 2, 1, 1],
                    padding='SAME',
                    name="pool")
                pooled_outputs.append(pooled)

        in_channel = num_filters
        curr_height = [(x-f+2)//2 for x,f in zip(curr_height, conv_filter)]

        return pooled_outputs, in_channel, curr_height


    def upper_conv_pool_layer(self, pooled_outputs, conv_filter, num_filters, in_channel, curr_height):
        """
        Constructs the convolution + maxpooling layer
        """

        # Increase dimension of padded_tensor
        # expanded_tensors = [tf.expand_dims(input_tensor, -1) for input_tensor in pooled_outputs]

        curr_pooled_outputs = []

        for i in range(len(pooled_outputs)):
            with tf.name_scope("conv-maxpool-{}".format(i)):

                filter_shape = [
                    conv_filter,
                    1,
                    in_channel,
                    num_filters]

                W = tf.Variable(
                    tf.truncated_normal(filter_shape, stddev=0.1), name="W")

                b = tf.Variable(tf.constant(0.1, shape=[num_filters]), name="b")

                conv = tf.nn.conv2d(
                    pooled_outputs[i],
                    W,
                    strides=[1,1,1,1],
                    padding="VALID",
                    name="conv")
                # RELU Non-linearity
                h = tf.nn.relu(tf.nn.bias_add(conv, b), name="relu")

                pooled = tf.nn.max_pool(
                    h,
                    ksize=[1, 2, 1, 1],
                    strides=[1, 2, 1, 1],
                    padding='SAME',
                    name="pool")
                curr_pooled_outputs.append(pooled)

        in_channel = num_filters
        curr_height = [(x-conv_filter+2)//2 for x in curr_height]

        return curr_pooled_outputs, in_channel, curr_height
